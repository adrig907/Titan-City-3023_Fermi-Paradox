The following demo was completed over the course of 48h 

To play, click a tile on the grid and hit 1, 2, or 3 to build a facility

To close the game, use Alt+F4

Created by Adrian Guerras, Anton Agapov, and Viktor Asprot